//! Production legal-action enumeration.
//!
//! This path preserves the action order of `GameState::legal_actions_reference`.
//! The take-mask table replaces a scan of all 31 masks. Main-phase buying power
//! is computed once, and payment enumeration removes only recursion levels
//! whose cost is zero. Those levels each have one branch and do not change order.
use super::{Action, ActionSet, CARDS, GOLD, GameState, Phase, returns};

const fn make_take_masks() -> ([[u8; 10]; 4], [usize; 4]) {
    let mut masks = [[0; 10]; 4];
    let mut lengths = [0; 4];
    let mut mask = 1u8;
    while mask < 32 {
        let count = mask.count_ones() as usize;
        if count <= 3 {
            masks[count][lengths[count]] = mask;
            lengths[count] += 1;
        }
        mask += 1;
    }
    (masks, lengths)
}

const TAKE_MASKS: ([[u8; 10]; 4], [usize; 4]) = make_take_masks();

pub(super) fn legal_actions(state: &GameState, out: &mut ActionSet) {
    out.clear();
    let player = &state.players[state.current_player()];
    match state.phase {
        Phase::Terminal => {}
        Phase::Main => {
            let bank_mask = (0..5).fold(0u8, |mask, color| {
                mask | (u8::from(state.bank[color] > 0) << color)
            });
            let available = bank_mask.count_ones().min(3) as usize;
            if available > 0 {
                let (masks, lengths) = &TAKE_MASKS;
                for &mask in &masks[available][..lengths[available]] {
                    if mask & !bank_mask == 0 {
                        out.push(Action::Take(std::array::from_fn(|color| {
                            u8::from(mask & (1 << color) != 0)
                        })));
                    }
                }
            }
            for color in 0..5 {
                if state.bank[color] >= 4 {
                    let mut take = [0; 5];
                    take[color] = 2;
                    out.push(Action::Take(take));
                }
            }

            let reserve_count = player.reserve_count();
            let can_reserve = reserve_count < 3;
            let buying_power: [u16; 5] = std::array::from_fn(|color| {
                u16::from(player.tokens[color]) + u16::from(player.bonuses[color])
            });
            let gold = player.tokens[GOLD];
            for slot in 0..12 {
                let card = state.market[slot];
                if card != super::NONE {
                    if affordable(card, &buying_power, gold) {
                        out.push(Action::BuyVisible(slot as u8));
                    }
                    if can_reserve {
                        out.push(Action::ReserveVisible(slot as u8));
                    }
                }
            }
            for tier in 0..3 {
                let reserved_card = player.reserved[tier].card;
                if reserved_card != super::NONE && affordable(reserved_card, &buying_power, gold) {
                    out.push(Action::BuyReserved(tier as u8));
                }
                if can_reserve && state.remaining[tier] > 0 {
                    out.push(Action::ReserveDeck(tier as u8));
                }
            }
        }
        Phase::Payment(source) => {
            let card = state.source_card(source).expect("valid pending card");
            let cost = state.cost(card);
            enumerate_payments(0, cost, &player.tokens, player.tokens[GOLD], [0; 5], out);
        }
        Phase::Return => returns(0, player.token_count() - 10, &player.tokens, [0; 6], out),
        Phase::Noble => {
            let mask = state.eligible();
            for noble in 0..10 {
                if mask & (1 << noble) != 0 {
                    out.push(Action::Noble(noble));
                }
            }
        }
    }
}

fn affordable(card: u8, buying_power: &[u16; 5], gold: u8) -> bool {
    let cost = &CARDS[card as usize].cost;
    let deficit: u16 = (0..5)
        .map(|color| u16::from(cost[color]).saturating_sub(buying_power[color]))
        .sum();
    deficit <= u16::from(gold)
}

fn enumerate_payments(
    index: usize,
    cost: [u8; 5],
    tokens: &[u8; 6],
    gold: u8,
    payment: [u8; 5],
    out: &mut ActionSet,
) {
    if gold == 0 {
        if (0..5).all(|color| cost[color] <= tokens[color]) {
            out.push(Action::Pay(cost));
        }
        return;
    }

    let Some(last_cost_color) = (0..5).rfind(|&color| cost[color] != 0) else {
        out.push(Action::Pay(payment));
        return;
    };
    enumerate_payments_through(index, last_cost_color, cost, tokens, gold, payment, out);
}

fn enumerate_payments_through(
    index: usize,
    last_cost_color: usize,
    cost: [u8; 5],
    tokens: &[u8; 6],
    gold: u8,
    mut payment: [u8; 5],
    out: &mut ActionSet,
) {
    if index > last_cost_color {
        out.push(Action::Pay(payment));
        return;
    }
    let min_wild = cost[index].saturating_sub(tokens[index]);
    let max_wild = cost[index].min(gold);
    for wild in min_wild..=max_wild {
        payment[index] = cost[index] - wild;
        enumerate_payments_through(
            index + 1,
            last_cost_color,
            cost,
            tokens,
            gold - wild,
            payment,
            out,
        );
    }
}
