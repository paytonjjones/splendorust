//! Research-only leaf queue. The queue receives tensors, never game states or RNGs.
use crate::transfer::Model;
use std::{
    io::{Read, Write},
    process::{Command, Stdio},
    sync::{OnceLock, mpsc},
    time::{Duration, Instant},
};
type Output = ([f32; 81], [f32; 2]);
struct Request {
    x: [f32; 392],
    reply: mpsc::SyncSender<Output>,
}
pub(crate) struct Evaluator {
    sender: mpsc::Sender<Request>,
}
struct Settings {
    size: usize,
    wait: Duration,
    backend: String,
}
fn settings() -> &'static Settings {
    static SETTINGS: OnceLock<Settings> = OnceLock::new();
    SETTINGS.get_or_init(|| {
        let size = std::env::var("SPLENDOR_INFERENCE_BATCH")
            .map(|x| x.parse().expect("batch size"))
            .unwrap_or(0);
        assert!(size <= 256);
        Settings {
            size,
            wait: Duration::from_micros(
                std::env::var("SPLENDOR_BATCH_WAIT_US")
                    .map(|x| x.parse().expect("batch wait"))
                    .unwrap_or(200),
            ),
            backend: std::env::var("SPLENDOR_BATCH_BACKEND").unwrap_or_else(|_| "native".into()),
        }
    })
}
impl Evaluator {
    fn new(model: &'static Model) -> Self {
        let (sender, receiver) = mpsc::channel::<Request>();
        std::thread::Builder::new().name("leaf-batch".into()).spawn(move || {
            let config = settings();
            let mut process = if config.backend == "mps" || config.backend == "torch-cpu" || config.backend == "coreml" {
                let path = model.batch_checkpoint.as_ref().expect("batched accelerator needs a flywheel checkpoint path");
                Some(Command::new(std::env::var("SPLENDOR_BATCH_PYTHON").expect("batch Python path"))
                    .args([std::env::var("SPLENDOR_BATCH_SCRIPT").expect("batch script path"), "--serve".into(), "--device".into(), if config.backend == "coreml" {
                            "coreml".into()
                        } else if config.backend == "mps" {"mps".into()} else {"cpu".into()}, "--model".into(), path.to_string_lossy().into_owned()])
                    .stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::inherit()).spawn().expect("start batch accelerator"))
            } else { assert!(config.backend == "native" || config.backend == "reference"); None };
            let mut batches = 0u64; let mut calls = 0u64; let mut kernel_seconds = 0.0;
            while let Ok(first) = receiver.recv() {
                let deadline = Instant::now() + config.wait;
                let mut pending = vec![first];
                while pending.len() < config.size {
                    match receiver.try_recv() {
                        Ok(request) => pending.push(request),
                        Err(mpsc::TryRecvError::Empty) => {
                            let remaining = deadline.saturating_duration_since(Instant::now());
                            if remaining.is_zero() { break; }
                            match receiver.recv_timeout(remaining) { Ok(request) => pending.push(request), Err(_) => break }
                        }
                        Err(mpsc::TryRecvError::Disconnected) => break,
                    }
                }
                let start = Instant::now();
                let outputs: Vec<Output> = if let Some(process) = process.as_mut() {
                    let mut bytes = Vec::with_capacity(4 + pending.len() * 392 * 4);
                    bytes.extend_from_slice(&(pending.len() as u32).to_le_bytes());
                    for request in &pending { for x in request.x { bytes.extend_from_slice(&x.to_le_bytes()); } }
                    let input = process.stdin.as_mut().unwrap();input.write_all(&bytes).expect("write batch");input.flush().expect("flush batch");
                    let mut bytes = vec![0u8; pending.len() * 83 * 4];process.stdout.as_mut().unwrap().read_exact(&mut bytes).expect("read batch outputs");
                    bytes.chunks_exact(83 * 4).map(|row| {
                        let values: [f32;83] = std::array::from_fn(|i| f32::from_le_bytes(row[i*4..i*4+4].try_into().unwrap()));
                        assert!(values.iter().all(|x|x.is_finite()));
                        (values[..81].try_into().unwrap(),values[81..].try_into().unwrap())
                    }).collect()
                } else { pending.iter().map(|r| if config.backend == "reference" { model.infer_original(&r.x) } else { model.infer(&r.x) }).collect() };
                kernel_seconds += start.elapsed().as_secs_f64();batches += 1;calls += pending.len() as u64;
                for (request, output) in pending.into_iter().zip(outputs) { let _ = request.reply.send(output); }
                if batches.is_multiple_of(1000) { eprintln!("leaf_batch backend={} batches={} calls={} mean_batch={} kernel_seconds={}",config.backend,batches,calls,calls as f64/batches as f64,kernel_seconds); }
            }
            if let Some(mut process) = process { drop(process.stdin.take()); let _ = process.wait(); }
        }).expect("start leaf queue");
        Self { sender }
    }
    fn evaluate(&self, x: &[f32; 392]) -> Output {
        let (reply, response) = mpsc::sync_channel(1);
        self.sender
            .send(Request { x: *x, reply })
            .expect("leaf queue alive");
        response.recv().expect("leaf evaluator alive")
    }
}
pub(crate) fn infer(model: &'static Model, x: &[f32; 392]) -> Output {
    if settings().size == 0 {
        model.infer(x)
    } else {
        model
            .batch
            .get_or_init(|| Evaluator::new(model))
            .evaluate(x)
    }
}
